var ball;
var wall1,wall2,wall3
var pressable=true;
var gameState;

function setup() {
  createCanvas(400, 400);
  
  ball= new Ball(50,171,70,70);
  
  wall1=new Wall(260,300,100,100);

}

function draw() {
  background(220);
  ball.display();
  wall1.display();
 if(ball.x>wall1.x-wall1.width/2 && ball.y>wall1.y-wall1.height/6){ 
  gameState="end";
 }
  if(gameState=="end"){
    ball.velocityX=0;
    ball.velocityY=0;
  }
  text("press space",150,100);
 keyPressed();
}

function collide(sprite1,sprite2){
  if (touched(sprite1,sprite2)){
    pressable=false;
    sprite1.velocityX=0;
    sprite1.velocityY=0;
  }
  
}

function keyPressed(theKey){
 
  if(keyCode==32&&pressable==true){
  ball.gravity=true;
  ball.velocityX=5;
    pressable=false;

  }
}